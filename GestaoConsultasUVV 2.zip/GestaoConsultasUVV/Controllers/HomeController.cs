using Microsoft.AspNetCore.Mvc;

namespace GestaoConsultasUVV.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            if (User.Identity != null && User.Identity.IsAuthenticated)
                return RedirectToAction("Index", "Consultas");

            return RedirectToAction("Login", "Account");
        }

        public IActionResult Error() => View();
    }
}
